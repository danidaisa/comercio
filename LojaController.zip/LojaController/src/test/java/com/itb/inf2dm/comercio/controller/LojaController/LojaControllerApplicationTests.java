package com.itb.inf2dm.comercio.controller.LojaController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
