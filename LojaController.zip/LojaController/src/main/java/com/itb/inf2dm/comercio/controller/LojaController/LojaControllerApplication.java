package com.itb.inf2dm.comercio.controller.LojaController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaControllerApplication.class, args);
	}

}
